package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BlackDeep = Color(0xFF000000)
val BlackSurface = Color(0xFF0A0A0A)
val BlackCard = Color(0xFF121212)
val WhitePure = Color(0xFFFFFFFF)
val WhiteMuted = Color(0xFFB3B3B3)
val WhiteBorder = Color(0x26FFFFFF) // 15% opacity white
