package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = WhitePure,
    onPrimary = BlackDeep,
    primaryContainer = BlackCard,
    onPrimaryContainer = WhitePure,
    secondary = WhiteMuted,
    onSecondary = BlackDeep,
    background = BlackDeep,
    onBackground = WhitePure,
    surface = BlackSurface,
    onSurface = WhitePure,
    surfaceVariant = BlackCard,
    onSurfaceVariant = WhiteMuted,
    outline = WhiteBorder
)

@Composable
fun SoundWaveTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
