import React from 'react';
import { Play } from 'lucide-react';
import { Playlist } from '../types';
import { usePlayerStore } from '../store/usePlayerStore';

interface PlaylistCardProps {
  playlist: Playlist;
}

export const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist }) => {
  const { setCurrentView, playSong } = usePlayerStore();

  const handlePlayDirect = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (playlist.songs.length > 0) {
      playSong(playlist.songs[0], playlist.songs);
    }
  };

  return (
    <div
      onClick={() => setCurrentView('playlist', playlist.id)}
      className="group relative p-3.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer select-none flex flex-col"
    >
      {/* Cover Image Container */}
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-neutral-900 border border-white/10 mb-3 shadow-md">
        <img
          src={playlist.coverUrl}
          alt={playlist.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Quick Play Button on Hover */}
        <button
          onClick={handlePlayDirect}
          className="absolute bottom-2.5 right-2.5 w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-2xl opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 hover:scale-110 active:scale-95 z-10"
          title={`Play ${playlist.title}`}
        >
          <Play className="w-4 h-4 fill-black translate-x-0.5" />
        </button>
      </div>

      {/* Info */}
      <h4 className="text-sm font-bold text-white truncate group-hover:text-white transition-colors">
        {playlist.title}
      </h4>
      <p className="text-xs text-neutral-400 line-clamp-2 mt-1 leading-relaxed">
        {playlist.description || `${playlist.songs.length} tracks`}
      </p>
    </div>
  );
};
