import React from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Volume2,
  VolumeX,
  Volume1,
  Maximize2,
  Heart,
  ListMusic
} from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';

interface PlayerProps {
  seekTo?: (seconds: number) => void;
  onToggleLyricsDrawer?: () => void;
}

const formatTime = (seconds: number): string => {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

export const Player: React.FC<PlayerProps> = ({ seekTo, onToggleLyricsDrawer }) => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    likedSongIds,
    togglePlay,
    nextSong,
    prevSong,
    seek,
    setVolume,
    toggleMute,
    toggleShuffle,
    cycleRepeatMode,
    toggleLike,
    setFullScreen
  } = usePlayerStore();

  if (!currentSong) return null;

  const isLiked = likedSongIds.includes(currentSong.id);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    seek(val);
    if (seekTo) seekTo(val);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
  };

  return (
    <footer className="h-20 md:h-[84px] bg-[#0A0A0A] border-t border-white/10 px-4 md:px-6 flex items-center justify-between z-40 select-none text-white shrink-0">
      {/* Left: Track Information */}
      <div className="flex items-center gap-3.5 w-1/4 min-w-[160px] max-w-[280px]">
        {/* Album Cover Thumbnail with Subtle Spin on Play */}
        <div
          onClick={() => setFullScreen(true)}
          className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 cursor-pointer border border-white/15 group shadow-md"
        >
          <img
            src={currentSong.coverUrl}
            alt={currentSong.title}
            className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${
              isPlaying ? 'animate-[spin_20s_linear_infinite]' : ''
            }`}
          />
          <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
            <Maximize2 className="w-4 h-4 text-white" />
          </div>
        </div>

        <div className="truncate">
          <div
            onClick={() => setFullScreen(true)}
            className="text-sm font-semibold truncate hover:underline cursor-pointer text-white"
          >
            {currentSong.title}
          </div>
          <div className="text-xs text-neutral-400 truncate mt-0.5">
            {currentSong.artist}
          </div>
        </div>

        <button
          onClick={() => toggleLike(currentSong.id)}
          className="p-1.5 rounded-full hover:bg-white/10 transition-colors text-neutral-400 hover:text-white"
          title={isLiked ? 'Unlike' : 'Like'}
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isLiked ? 'text-white fill-white' : 'text-neutral-400'
            }`}
          />
        </button>
      </div>

      {/* Center: Controls & Progress */}
      <div className="flex flex-col items-center max-w-[540px] flex-1 px-4">
        {/* Buttons */}
        <div className="flex items-center gap-3 md:gap-5 mb-1.5">
          <button
            onClick={toggleShuffle}
            className={`p-1.5 rounded-full transition-colors ${
              isShuffle ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
            }`}
            title={`Shuffle: ${isShuffle ? 'On' : 'Off'}`}
          >
            <Shuffle className="w-4 h-4" />
          </button>

          <button
            onClick={prevSong}
            className="p-1.5 rounded-full text-neutral-300 hover:text-white transition-colors"
            title="Previous (ArrowLeft seek)"
          >
            <SkipBack className="w-5 h-5 fill-current" />
          </button>

          <button
            onClick={togglePlay}
            className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg"
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-black" />
            ) : (
              <Play className="w-4 h-4 fill-black translate-x-0.5" />
            )}
          </button>

          <button
            onClick={nextSong}
            className="p-1.5 rounded-full text-neutral-300 hover:text-white transition-colors"
            title="Next"
          >
            <SkipForward className="w-5 h-5 fill-current" />
          </button>

          <button
            onClick={cycleRepeatMode}
            className={`p-1.5 rounded-full transition-colors ${
              repeatMode !== 'off' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
            }`}
            title={`Repeat: ${repeatMode}`}
          >
            {repeatMode === 'one' ? (
              <Repeat1 className="w-4 h-4" />
            ) : (
              <Repeat className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Draggable Progress Bar with Real Timestamps */}
        <div className="w-full flex items-center gap-2.5 text-[11px] text-neutral-400 font-mono">
          <span className="w-9 text-right">{formatTime(currentTime)}</span>
          <div className="relative flex-1 flex items-center group">
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeekChange}
              className="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white focus:outline-none group-hover:h-1.5 transition-all"
              style={{
                background: `linear-gradient(to right, #ffffff ${progressPercent}%, rgba(255,255,255,0.2) ${progressPercent}%)`
              }}
            />
          </div>
          <span className="w-9">{formatTime(duration)}</span>
        </div>
      </div>

      {/* Right: Volume & Utilities */}
      <div className="flex items-center justify-end gap-3 w-1/4 min-w-[140px]">
        {/* Toggle Lyrics Button */}
        {onToggleLyricsDrawer && (
          <button
            onClick={onToggleLyricsDrawer}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Toggle Lyrics Panel"
          >
            <ListMusic className="w-4 h-4" />
          </button>
        )}

        {/* Volume Controls */}
        <div className="hidden sm:flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="p-1 text-neutral-400 hover:text-white transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4" />
            ) : volume < 0.5 ? (
              <Volume1 className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={isMuted ? 0 : volume}
            onChange={handleVolumeChange}
            className="w-20 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white group-hover:h-1.5 transition-all"
            style={{
              background: `linear-gradient(to right, #ffffff ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(isMuted ? 0 : volume) * 100}%)`
            }}
          />
        </div>

        {/* Fullscreen Expand */}
        <button
          onClick={() => setFullScreen(true)}
          className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Full Screen Player"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </footer>
  );
};
