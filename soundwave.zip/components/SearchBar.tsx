import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';

export const SearchBar: React.FC = () => {
  const { searchQuery, setSearchQuery, searchFilter, setSearchFilter } = usePlayerStore();
  const [localInput, setLocalInput] = useState(searchQuery);

  // 300ms debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(localInput);
    }, 300);
    return () => clearTimeout(timer);
  }, [localInput, setSearchQuery]);

  const filters = [
    { id: 'all', label: 'All' },
    { id: 'songs', label: 'Songs' },
    { id: 'artists', label: 'Artists' },
    { id: 'albums', label: 'Albums' },
    { id: 'playlists', label: 'Playlists' }
  ] as const;

  return (
    <div className="w-full space-y-3">
      {/* Search Input Box */}
      <div className="relative flex items-center w-full max-w-xl">
        <Search className="absolute left-3.5 w-4 h-4 text-neutral-400 pointer-events-none" />
        <input
          id="soundwave-search-input"
          type="text"
          value={localInput}
          onChange={(e) => setLocalInput(e.target.value)}
          placeholder="What do you want to play? (Ctrl+K)"
          className="w-full pl-10 pr-24 py-2.5 rounded-full bg-white/[0.07] hover:bg-white/[0.1] focus:bg-white/[0.12] border border-white/10 focus:border-white/40 text-sm text-white placeholder-neutral-500 focus:outline-none transition-all shadow-inner"
        />

        {/* Clear Button & Shortcut Hint */}
        <div className="absolute right-3 flex items-center gap-1.5">
          {localInput ? (
            <button
              onClick={() => setLocalInput('')}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-neutral-500 bg-white/5 border border-white/10 rounded">
              Ctrl+K
            </kbd>
          )}
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar text-xs">
        {filters.map((f) => {
          const isActive = searchFilter === f.id;
          return (
            <button
              key={f.id}
              onClick={() => setSearchFilter(f.id)}
              className={`px-3.5 py-1.5 rounded-full font-medium transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-white text-black font-semibold shadow'
                  : 'bg-white/5 text-neutral-300 hover:bg-white/10 hover:text-white border border-white/10'
              }`}
            >
              {f.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};
