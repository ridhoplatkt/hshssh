import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home,
  Search,
  Library,
  PlusSquare,
  Heart,
  Music2,
  Trash2,
  X,
  Volume2
} from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';

export const Sidebar: React.FC = () => {
  const {
    currentView,
    selectedPlaylistId,
    playlists,
    likedSongIds,
    isSidebarOpen,
    setCurrentView,
    setSidebarOpen,
    createPlaylist,
    deletePlaylist
  } = usePlayerStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Lock body scroll on mobile when sidebar open
  useEffect(() => {
    if (isSidebarOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isSidebarOpen]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTitle.trim()) {
      createPlaylist(newTitle.trim(), newDesc.trim());
      setNewTitle('');
      setNewDesc('');
      setIsModalOpen(false);
    }
  };

  const sidebarContent = (
    <div className="w-[260px] h-full bg-[#0A0A0A] border-r border-white/10 flex flex-col select-none text-neutral-300">
      {/* Brand Header */}
      <div className="p-6 pb-4 flex items-center justify-between">
        <div
          onClick={() => setCurrentView('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-lg bg-white/10 border border-white/20 flex items-center justify-center text-white group-hover:scale-105 group-hover:border-white/40 transition-all">
            <Volume2 className="w-4 h-4 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white group-hover:text-white transition-colors">
            SoundWave
          </span>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="md:hidden p-1.5 rounded-md hover:bg-white/10 text-neutral-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Nav */}
      <div className="px-3 py-2 space-y-1">
        <button
          onClick={() => setCurrentView('home')}
          className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            currentView === 'home'
              ? 'bg-white/10 text-white border border-white/15'
              : 'hover:bg-white/5 hover:text-white text-neutral-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Home</span>
        </button>

        <button
          onClick={() => setCurrentView('search')}
          className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            currentView === 'search'
              ? 'bg-white/10 text-white border border-white/15'
              : 'hover:bg-white/5 hover:text-white text-neutral-400'
          }`}
        >
          <Search className="w-5 h-5" />
          <span>Search</span>
        </button>

        <button
          onClick={() => setCurrentView('library')}
          className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            currentView === 'library'
              ? 'bg-white/10 text-white border border-white/15'
              : 'hover:bg-white/5 hover:text-white text-neutral-400'
          }`}
        >
          <Library className="w-5 h-5" />
          <span>Your Library</span>
        </button>
      </div>

      {/* Action Buttons */}
      <div className="px-3 pt-4 pb-2 space-y-1 border-t border-white/10 mt-2">
        <button
          onClick={() => setIsModalOpen(true)}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-neutral-300 hover:text-white hover:bg-white/5 transition-all group"
        >
          <div className="w-6 h-6 rounded bg-white/10 border border-white/10 flex items-center justify-center group-hover:bg-white/20 transition-all">
            <PlusSquare className="w-4 h-4 text-white" />
          </div>
          <span>Create Playlist</span>
        </button>

        <button
          onClick={() => setCurrentView('liked')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all group ${
            currentView === 'liked'
              ? 'bg-white/10 text-white font-semibold border border-white/15'
              : 'text-neutral-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <div className="w-6 h-6 rounded bg-white/15 border border-white/20 flex items-center justify-center group-hover:scale-105 transition-all">
            <Heart className="w-3.5 h-3.5 text-white fill-white" />
          </div>
          <div className="flex-1 text-left flex items-center justify-between">
            <span>Liked Songs</span>
            <span className="text-xs text-neutral-500 font-normal">
              {likedSongIds.length}
            </span>
          </div>
        </button>
      </div>

      {/* Playlist List Header */}
      <div className="px-6 pt-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-neutral-500">
        Playlists
      </div>

      {/* Scrollable Playlist List */}
      <div className="flex-1 overflow-y-auto px-3 py-1 space-y-0.5 custom-scrollbar">
        {playlists.map((playlist) => {
          const isSelected = currentView === 'playlist' && selectedPlaylistId === playlist.id;
          return (
            <div
              key={playlist.id}
              onClick={() => setCurrentView('playlist', playlist.id)}
              className={`group flex items-center justify-between px-3 py-2 rounded-lg text-sm cursor-pointer transition-all ${
                isSelected
                  ? 'bg-white/15 text-white font-medium border border-white/10'
                  : 'hover:bg-white/5 text-neutral-400 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Music2 className="w-4 h-4 text-neutral-500 group-hover:text-white shrink-0" />
                <span className="truncate">{playlist.title}</span>
              </div>

              {playlist.isCustom && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deletePlaylist(playlist.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-opacity"
                  title="Delete playlist"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* SoundWave Premium Indicator */}
      <div className="p-4 border-t border-white/10 m-2 rounded-lg bg-black/40 border border-white/5">
        <div className="text-xs font-semibold text-white">SoundWave Lossless</div>
        <div className="text-[11px] text-neutral-400 mt-0.5">High-Fidelity Web Audio</div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block h-full shrink-0 z-20">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer with Animated Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            />

            {/* Sliding Sidebar */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
              className="relative z-50 h-full shadow-2xl"
            >
              {sidebarContent}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Create Playlist Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative z-10 w-full max-w-md bg-[#0e0e0e] border border-white/15 rounded-xl p-6 shadow-2xl text-white"
            >
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <h3 className="text-lg font-bold">Create New Playlist</h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 rounded-md text-neutral-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateSubmit} className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">
                    Playlist Title
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Midnight Beats"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-black/70 border border-white/20 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-all text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">
                    Description (optional)
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Add an optional description"
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-black/70 border border-white/20 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-all text-sm resize-none"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-lg text-sm text-neutral-300 hover:text-white hover:bg-white/5 border border-white/10"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg text-sm font-semibold bg-white text-black hover:bg-neutral-200 active:scale-95 transition-all"
                  >
                    Create
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
