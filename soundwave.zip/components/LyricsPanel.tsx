import React, { useRef, useEffect } from 'react';
import { Heart, Music, ListOrdered, X } from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';
import { Equalizer } from './Equalizer';

interface LyricsPanelProps {
  seekTo?: (seconds: number) => void;
  onClose?: () => void;
}

export const LyricsPanel: React.FC<LyricsPanelProps> = ({ seekTo, onClose }) => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    queue,
    queueIndex,
    likedSongIds,
    toggleLike,
    seek,
    playSong
  } = usePlayerStore();

  const activeLyricRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (activeLyricRef.current) {
      activeLyricRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });
    }
  }, [currentTime]);

  if (!currentSong) return null;

  const isLiked = likedSongIds.includes(currentSong.id);
  const nextInQueue = queue.slice(queueIndex + 1, queueIndex + 5);

  // Calculate current active lyric index
  let activeLyricIndex = -1;
  for (let i = 0; i < currentSong.lyrics.length; i++) {
    if (currentTime >= currentSong.lyrics[i].time) {
      activeLyricIndex = i;
    } else {
      break;
    }
  }

  return (
    <aside className="w-full h-full bg-[#0A0A0A] border-l border-white/10 flex flex-col p-4 overflow-y-auto custom-scrollbar select-none text-white">
      {/* Header with Title & Close (for tablet/mobile drawer) */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
            Now Playing
          </span>
          <Equalizer isPlaying={isPlaying} barCount={8} height={14} width={28} />
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/10 xl:hidden"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Large Album Cover Art */}
      <div className="relative aspect-square w-full rounded-xl overflow-hidden border border-white/10 shadow-lg group mb-4">
        <img
          src={currentSong.coverUrl}
          alt={currentSong.title}
          className={`w-full h-full object-cover transition-transform duration-700 ${
            isPlaying ? 'scale-105' : 'scale-100'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
          <div className="truncate">
            <h3 className="font-bold text-base truncate">{currentSong.title}</h3>
            <p className="text-xs text-neutral-300 truncate">{currentSong.artist}</p>
          </div>
          <button
            onClick={() => toggleLike(currentSong.id)}
            className="p-2 rounded-full bg-black/50 border border-white/20 hover:scale-110 active:scale-95 transition-all"
          >
            <Heart
              className={`w-4 h-4 ${isLiked ? 'fill-white text-white' : 'text-neutral-300'}`}
            />
          </button>
        </div>
      </div>

      {/* Synchronized Lyrics Container */}
      <div className="flex-1 min-h-[180px] max-h-[260px] rounded-xl border border-white/10 bg-black/40 p-3.5 flex flex-col mb-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
          <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
            <Music className="w-3.5 h-3.5 text-white" />
            Live Lyrics
          </span>
          <span className="text-[10px] text-neutral-500 font-mono">Sync</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
          {currentSong.lyrics.length > 0 ? (
            currentSong.lyrics.map((line, idx) => {
              const isActive = idx === activeLyricIndex;
              return (
                <div
                  key={idx}
                  ref={isActive ? activeLyricRef : null}
                  onClick={() => {
                    seek(line.time);
                    if (seekTo) seekTo(line.time);
                  }}
                  className={`text-xs cursor-pointer py-1 px-2 rounded-md transition-all duration-200 ${
                    isActive
                      ? 'text-white font-bold bg-white/10 border-l-2 border-white pl-2'
                      : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  {line.text}
                </div>
              );
            })
          ) : (
            <div className="text-center text-xs text-neutral-500 my-auto py-6">
              No synced lyrics available
            </div>
          )}
        </div>
      </div>

      {/* Next in Queue Section */}
      <div className="rounded-xl border border-white/10 bg-black/40 p-3.5 flex flex-col">
        <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
          <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
            <ListOrdered className="w-3.5 h-3.5 text-white" />
            Next in Queue
          </span>
          <span className="text-[10px] text-neutral-500">{nextInQueue.length} upcoming</span>
        </div>

        <div className="space-y-1.5">
          {nextInQueue.length > 0 ? (
            nextInQueue.map((track, i) => (
              <div
                key={track.id + i}
                onClick={() => playSong(track, queue)}
                className="group flex items-center gap-2.5 p-1.5 rounded-lg hover:bg-white/5 cursor-pointer transition-colors"
              >
                <img
                  src={track.coverUrl}
                  alt={track.title}
                  className="w-8 h-8 rounded object-cover border border-white/10 shrink-0"
                />
                <div className="min-w-0 flex-1 truncate">
                  <div className="text-xs font-medium text-neutral-200 group-hover:text-white truncate">
                    {track.title}
                  </div>
                  <div className="text-[11px] text-neutral-500 truncate">
                    {track.artist}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-neutral-500 py-3 text-center">
              End of queue reached
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
