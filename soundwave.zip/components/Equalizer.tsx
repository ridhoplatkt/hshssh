import React, { useEffect, useRef } from 'react';

interface EqualizerProps {
  isPlaying: boolean;
  barCount?: number;
  height?: number;
  width?: number;
  color?: string;
}

export const Equalizer: React.FC<EqualizerProps> = ({
  isPlaying,
  barCount = 18,
  height = 36,
  width = 80,
  color = '#ffffff'
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    // Current bar heights
    const bars: number[] = Array.from({ length: barCount }, () => Math.random() * 0.4 + 0.1);
    const speeds: number[] = Array.from({ length: barCount }, () => (Math.random() * 0.08 + 0.04));

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const totalSpacing = 2; // px spacing
      const barWidth = Math.max(2, (width - (barCount - 1) * totalSpacing) / barCount);

      for (let i = 0; i < barCount; i++) {
        if (isPlaying) {
          bars[i] += speeds[i];
          if (bars[i] > 1 || bars[i] < 0.1) {
            speeds[i] = -speeds[i];
          }
        } else {
          // Slowly decay to static idle baseline
          bars[i] = Math.max(0.12, bars[i] * 0.95);
        }

        const barHeight = bars[i] * height;
        const x = i * (barWidth + totalSpacing);
        const y = height - barHeight;

        // Draw rounded top bar
        ctx.fillStyle = color;
        ctx.globalAlpha = isPlaying ? 0.85 : 0.3;

        // Custom rounded bar
        const radius = Math.min(barWidth / 2, 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + barWidth - radius, y);
        ctx.quadraticCurveTo(x + barWidth, y, x + barWidth, y + radius);
        ctx.lineTo(x + barWidth, height);
        ctx.lineTo(x, height);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, barCount, height, width, color]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="inline-block"
      title={isPlaying ? 'Playing' : 'Paused'}
    />
  );
};
