import React from 'react';
import { Play, Pause, Heart, MoreHorizontal } from 'lucide-react';
import { Song } from '../types';
import { usePlayerStore } from '../store/usePlayerStore';
import { Equalizer } from './Equalizer';

interface SongRowProps {
  song: Song;
  index: number;
  playlistContext?: Song[];
}

const formatTime = (seconds: number): string => {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

export const SongRow: React.FC<SongRowProps> = ({ song, index, playlistContext }) => {
  const {
    currentSong,
    isPlaying,
    likedSongIds,
    playSong,
    togglePlay,
    toggleLike,
    openContextMenu
  } = usePlayerStore();

  const isCurrent = currentSong?.id === song.id;
  const isLiked = likedSongIds.includes(song.id);

  const handleClickPlay = () => {
    if (isCurrent) {
      togglePlay();
    } else {
      playSong(song, playlistContext);
    }
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    openContextMenu(e.clientX, e.clientY, song);
  };

  return (
    <div
      onContextMenu={handleContextMenu}
      onClick={handleClickPlay}
      className={`group flex items-center justify-between px-3 md:px-4 py-2.5 rounded-lg cursor-pointer transition-all border border-transparent select-none ${
        isCurrent
          ? 'bg-white/10 border-white/10 text-white'
          : 'hover:bg-white/5 hover:border-white/5 text-neutral-300'
      }`}
    >
      {/* Left: Index / Play Icon / Album Art & Title */}
      <div className="flex items-center gap-3.5 min-w-0 flex-1">
        {/* Index or Equalizer or Play Button */}
        <div className="w-6 text-center text-xs font-mono text-neutral-500 shrink-0">
          {isCurrent && isPlaying ? (
            <Equalizer isPlaying={true} barCount={4} height={14} width={16} />
          ) : (
            <>
              <span className="group-hover:hidden">{index + 1}</span>
              <Play className="w-3.5 h-3.5 text-white fill-white hidden group-hover:inline-block translate-x-0.5" />
            </>
          )}
        </div>

        {/* Cover Art */}
        <img
          src={song.coverUrl}
          alt={song.title}
          className="w-10 h-10 rounded-md object-cover shrink-0 border border-white/10"
        />

        {/* Title and Artist */}
        <div className="min-w-0 truncate">
          <div
            className={`text-sm font-semibold truncate ${
              isCurrent ? 'text-white' : 'text-neutral-200 group-hover:text-white'
            }`}
          >
            {song.title}
          </div>
          <div className="text-xs text-neutral-400 truncate mt-0.5">
            {song.artist}
          </div>
        </div>
      </div>

      {/* Middle: Album Name (Hidden on Mobile) */}
      <div className="hidden md:block w-1/4 px-4 text-xs text-neutral-400 truncate">
        {song.album}
      </div>

      {/* Right: Like, Duration & More */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLike(song.id);
          }}
          className={`p-1.5 rounded-full hover:bg-white/10 transition-colors ${
            isLiked ? 'text-white' : 'opacity-0 group-hover:opacity-100 text-neutral-400 hover:text-white'
          }`}
          title={isLiked ? 'Unlike' : 'Like'}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-white text-white' : ''}`} />
        </button>

        <span className="text-xs font-mono text-neutral-400 w-10 text-right">
          {formatTime(song.duration)}
        </span>

        <button
          onClick={(e) => {
            e.stopPropagation();
            const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
            openContextMenu(rect.left - 100, rect.bottom + 5, song);
          }}
          className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 opacity-0 group-hover:opacity-100 transition-all"
          title="More options"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
