import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Minimize2,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Volume2,
  VolumeX,
  Heart,
  Music
} from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';
import { Equalizer } from './Equalizer';

interface FullScreenPlayerProps {
  seekTo?: (seconds: number) => void;
}

const formatTime = (seconds: number): string => {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({ seekTo }) => {
  const {
    isFullScreen,
    setFullScreen,
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    likedSongIds,
    togglePlay,
    nextSong,
    prevSong,
    seek,
    setVolume,
    toggleMute,
    toggleShuffle,
    cycleRepeatMode,
    toggleLike
  } = usePlayerStore();

  const activeLyricRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll lyrics
  useEffect(() => {
    if (activeLyricRef.current) {
      activeLyricRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [currentTime]);

  if (!isFullScreen || !currentSong) return null;

  const isLiked = likedSongIds.includes(currentSong.id);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  // Find active lyric line index
  let activeLyricIndex = -1;
  for (let i = 0; i < currentSong.lyrics.length; i++) {
    if (currentTime >= currentSong.lyrics[i].time) {
      activeLyricIndex = i;
    } else {
      break;
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.98, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.98, y: 30 }}
        transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
        className="fixed inset-0 z-50 bg-[#000000] text-white flex flex-col p-6 md:p-12 overflow-hidden select-none"
      >
        {/* Top Bar */}
        <div className="flex items-center justify-between pb-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <span className="text-xs tracking-widest uppercase font-semibold text-neutral-400">
              Playing from {currentSong.album}
            </span>
            <Equalizer isPlaying={isPlaying} barCount={12} height={20} width={45} />
          </div>

          <button
            onClick={() => setFullScreen(false)}
            className="p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white transition-all active:scale-95"
            title="Minimize (Esc)"
          >
            <Minimize2 className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Two Columns on Large Screens */}
        <div className="flex-1 flex flex-col lg:flex-row items-center justify-center gap-10 lg:gap-16 py-8 overflow-hidden max-w-6xl mx-auto w-full">
          {/* Left Column: Rotating Vinyl / Album Art */}
          <div className="flex flex-col items-center justify-center text-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80 lg:w-96 lg:h-96 rounded-full p-2 border border-white/20 bg-gradient-to-tr from-neutral-900 via-black to-neutral-900 shadow-2xl flex items-center justify-center">
              {/* Outer Grooves */}
              <div className="absolute inset-4 rounded-full border border-white/10 pointer-events-none" />
              <div className="absolute inset-10 rounded-full border border-white/5 pointer-events-none" />

              {/* Album Art with Smooth 20s Rotation */}
              <div
                className={`w-44 h-44 md:w-56 md:h-56 lg:w-64 lg:h-64 rounded-full overflow-hidden border-2 border-white/25 shadow-inner transition-transform duration-700 ${
                  isPlaying ? 'animate-[spin_20s_linear_infinite]' : ''
                }`}
              >
                <img
                  src={currentSong.coverUrl}
                  alt={currentSong.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Center Spindle */}
              <div className="absolute w-8 h-8 rounded-full bg-black border-2 border-white/40 shadow flex items-center justify-center pointer-events-none">
                <div className="w-2.5 h-2.5 rounded-full bg-white/80" />
              </div>
            </div>

            {/* Title & Artist */}
            <div className="mt-6">
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white flex items-center justify-center gap-3">
                <span>{currentSong.title}</span>
                <button
                  onClick={() => toggleLike(currentSong.id)}
                  className="p-1 text-neutral-400 hover:text-white transition-colors"
                >
                  <Heart
                    className={`w-6 h-6 ${
                      isLiked ? 'text-white fill-white' : 'text-neutral-400'
                    }`}
                  />
                </button>
              </h1>
              <p className="text-sm md:text-base text-neutral-400 mt-1">
                {currentSong.artist} • <span className="text-neutral-500">{currentSong.genre}</span>
              </p>
            </div>
          </div>

          {/* Right Column: Synced Lyrics Real-Time Scroll */}
          <div className="flex-1 w-full max-w-md h-64 lg:h-[420px] rounded-xl border border-white/10 bg-black/40 p-6 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-2">
                <Music className="w-3.5 h-3.5 text-white" />
                Synchronized Lyrics
              </span>
              <span className="text-xs text-neutral-500 font-mono">Live</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              {currentSong.lyrics && currentSong.lyrics.length > 0 ? (
                currentSong.lyrics.map((line, idx) => {
                  const isActive = idx === activeLyricIndex;
                  return (
                    <div
                      key={idx}
                      ref={isActive ? activeLyricRef : null}
                      onClick={() => {
                        seek(line.time);
                        if (seekTo) seekTo(line.time);
                      }}
                      className={`text-base md:text-lg cursor-pointer transition-all duration-300 py-1 px-2 rounded-lg ${
                        isActive
                          ? 'text-white font-bold scale-105 bg-white/10 border-l-2 border-white pl-3'
                          : 'text-neutral-500 hover:text-neutral-300 font-medium'
                      }`}
                    >
                      {line.text}
                    </div>
                  );
                })
              ) : (
                <div className="text-center text-neutral-500 my-auto py-10">
                  Instrumental or no lyrics available
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Playback Controls */}
        <div className="w-full max-w-3xl mx-auto pt-4 pb-2">
          {/* Progress Bar */}
          <div className="flex items-center gap-4 text-xs font-mono text-neutral-400 mb-4">
            <span>{formatTime(currentTime)}</span>
            <div className="flex-1 relative flex items-center">
              <input
                type="range"
                min={0}
                max={duration || 100}
                step={0.1}
                value={currentTime}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  seek(val);
                  if (seekTo) seekTo(val);
                }}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
                style={{
                  background: `linear-gradient(to right, #ffffff ${progressPercent}%, rgba(255,255,255,0.2) ${progressPercent}%)`
                }}
              />
            </div>
            <span>{formatTime(duration)}</span>
          </div>

          {/* Buttons Row */}
          <div className="flex items-center justify-between">
            <button
              onClick={toggleShuffle}
              className={`p-2 rounded-full transition-colors ${
                isShuffle ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
              }`}
            >
              <Shuffle className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-6">
              <button
                onClick={prevSong}
                className="p-2 text-neutral-300 hover:text-white transition-colors"
              >
                <SkipBack className="w-7 h-7 fill-current" />
              </button>

              <button
                onClick={togglePlay}
                className="w-14 h-14 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-2xl"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6 fill-black" />
                ) : (
                  <Play className="w-6 h-6 fill-black translate-x-0.5" />
                )}
              </button>

              <button
                onClick={nextSong}
                className="p-2 text-neutral-300 hover:text-white transition-colors"
              >
                <SkipForward className="w-7 h-7 fill-current" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={cycleRepeatMode}
                className={`p-2 rounded-full transition-colors ${
                  repeatMode !== 'off' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {repeatMode === 'one' ? (
                  <Repeat1 className="w-5 h-5" />
                ) : (
                  <Repeat className="w-5 h-5" />
                )}
              </button>

              {/* Volume */}
              <div className="hidden sm:flex items-center gap-2">
                <button
                  onClick={toggleMute}
                  className="p-1 text-neutral-400 hover:text-white"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-24 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
                />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
