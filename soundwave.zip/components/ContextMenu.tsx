import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play,
  ListPlus,
  Heart,
  FolderPlus,
  Share2,
  Download,
  ChevronRight
} from 'lucide-react';
import { usePlayerStore } from '../store/usePlayerStore';

export const ContextMenu: React.FC = () => {
  const {
    contextMenu,
    closeContextMenu,
    playSong,
    addToQueue,
    toggleLike,
    likedSongIds,
    playlists,
    addSongToPlaylist,
    showToast
  } = usePlayerStore();

  const menuRef = useRef<HTMLDivElement | null>(null);
  const [showPlaylistsSubmenu, setShowPlaylistsSubmenu] = useState(false);

  // Close when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        closeContextMenu();
      }
    };
    if (contextMenu.isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [contextMenu.isOpen, closeContextMenu]);

  if (!contextMenu.isOpen || !contextMenu.song) return null;

  const { song, x, y } = contextMenu;
  const isLiked = likedSongIds.includes(song.id);

  // Adjust coordinates so it doesn't go offscreen
  const adjustedX = Math.min(x, window.innerWidth - 220);
  const adjustedY = Math.min(y, window.innerHeight - 280);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`Now playing "${song.title}" by ${song.artist} on SoundWave`);
      showToast('Copied share text to clipboard!');
    } else {
      showToast(`Shared "${song.title}"`);
    }
    closeContextMenu();
  };

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = song.audioUrl;
    a.download = `${song.artist} - ${song.title}.mp3`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(`Downloading "${song.title}"...`);
    closeContextMenu();
  };

  return (
    <AnimatePresence>
      <motion.div
        ref={menuRef}
        initial={{ opacity: 0, scale: 0.95, y: -5 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15 }}
        style={{ top: `${adjustedY}px`, left: `${adjustedX}px` }}
        className="fixed z-50 w-52 bg-[#121212] border border-white/15 rounded-xl shadow-2xl p-1.5 text-neutral-200 text-xs font-medium select-none"
      >
        {/* Track header */}
        <div className="px-3 py-2 border-b border-white/10 mb-1">
          <div className="font-semibold text-white truncate">{song.title}</div>
          <div className="text-[11px] text-neutral-400 truncate">{song.artist}</div>
        </div>

        {/* Play Action */}
        <button
          onClick={() => {
            playSong(song);
            closeContextMenu();
          }}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
        >
          <Play className="w-4 h-4" />
          <span>Play Now</span>
        </button>

        {/* Add to Queue */}
        <button
          onClick={() => {
            addToQueue(song);
            closeContextMenu();
          }}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
        >
          <ListPlus className="w-4 h-4" />
          <span>Add to Queue</span>
        </button>

        {/* Add to Playlist Submenu */}
        <div
          className="relative"
          onMouseEnter={() => setShowPlaylistsSubmenu(true)}
          onMouseLeave={() => setShowPlaylistsSubmenu(false)}
        >
          <button className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors">
            <div className="flex items-center gap-2.5">
              <FolderPlus className="w-4 h-4" />
              <span>Add to Playlist</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-neutral-400" />
          </button>

          {/* Submenu */}
          {showPlaylistsSubmenu && (
            <div className="absolute left-full top-0 ml-1 w-48 bg-[#181818] border border-white/15 rounded-xl p-1.5 shadow-2xl space-y-1">
              <div className="px-2 py-1 text-[10px] uppercase font-bold text-neutral-500">
                Choose Playlist
              </div>
              {playlists
                .filter((p) => p.id !== 'pl-liked')
                .map((pl) => (
                  <button
                    key={pl.id}
                    onClick={() => {
                      addSongToPlaylist(pl.id, song);
                      closeContextMenu();
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-neutral-300 hover:text-white text-xs truncate"
                  >
                    {pl.title}
                  </button>
                ))}
            </div>
          )}
        </div>

        {/* Toggle Like */}
        <button
          onClick={() => {
            toggleLike(song.id);
            closeContextMenu();
          }}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
        >
          <Heart
            className={`w-4 h-4 ${isLiked ? 'fill-white text-white' : ''}`}
          />
          <span>{isLiked ? 'Remove from Liked' : 'Save to Liked Songs'}</span>
        </button>

        <div className="h-[1px] bg-white/10 my-1" />

        {/* Share */}
        <button
          onClick={handleShare}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
        >
          <Share2 className="w-4 h-4" />
          <span>Share</span>
        </button>

        {/* Download */}
        <button
          onClick={handleDownload}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Download Audio</span>
        </button>
      </motion.div>
    </AnimatePresence>
  );
};
