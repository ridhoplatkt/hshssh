import React from 'react';
import { motion } from 'framer-motion';
import { usePlayerStore } from '../store/usePlayerStore';

export const HamburgerMenu: React.FC = () => {
  const { isSidebarOpen, toggleSidebar } = usePlayerStore();

  return (
    <button
      onClick={toggleSidebar}
      className="md:hidden relative w-10 h-10 flex flex-col items-center justify-center rounded-lg border border-white/10 bg-black/60 hover:bg-white/5 active:scale-95 transition-all z-50 text-white"
      aria-label="Toggle Navigation Menu"
    >
      <div className="w-5 h-4 flex flex-col justify-between items-center relative">
        {/* Top bar */}
        <motion.span
          animate={
            isSidebarOpen
              ? { rotate: 45, y: 7, backgroundColor: '#ffffff' }
              : { rotate: 0, y: 0, backgroundColor: '#ffffff' }
          }
          transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
          className="w-5 h-[2px] bg-white rounded-full origin-center"
        />

        {/* Middle bar */}
        <motion.span
          animate={
            isSidebarOpen
              ? { opacity: 0, scale: 0.5 }
              : { opacity: 1, scale: 1 }
          }
          transition={{ duration: 0.2, ease: 'easeInOut' }}
          className="w-5 h-[2px] bg-white rounded-full"
        />

        {/* Bottom bar */}
        <motion.span
          animate={
            isSidebarOpen
              ? { rotate: -45, y: -7, backgroundColor: '#ffffff' }
              : { rotate: 0, y: 0, backgroundColor: '#ffffff' }
          }
          transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
          className="w-5 h-[2px] bg-white rounded-full origin-center"
        />
      </div>
    </button>
  );
};
