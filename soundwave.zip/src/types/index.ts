export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // seconds
  coverUrl: string;
  audioUrl: string;
  genre: string;
  lyrics: LyricLine[];
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  songs: Song[];
  isCustom?: boolean;
}

export type RepeatMode = 'off' | 'all' | 'one';

export interface ContextMenuState {
  isOpen: boolean;
  x: number;
  y: number;
  song: Song | null;
}

export type ViewMode = 'home' | 'search' | 'library' | 'playlist' | 'liked';
