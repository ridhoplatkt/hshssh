import { create } from 'zustand';
import { Song, Playlist, RepeatMode, ContextMenuState, ViewMode } from '../types';
import { SONGS_DATA } from '../data/songs';
import { INITIAL_PLAYLISTS } from '../data/playlists';

interface PlayerState {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  queue: Song[];
  queueIndex: number;
  likedSongIds: string[];
  recentlyPlayed: Song[];
  playlists: Playlist[];
  currentView: ViewMode;
  selectedPlaylistId: string | null;
  isFullScreen: boolean;
  isSidebarOpen: boolean;
  contextMenu: ContextMenuState;
  searchQuery: string;
  searchFilter: 'all' | 'songs' | 'albums' | 'artists' | 'playlists';
  toastMessage: string | null;

  // Actions
  setCurrentSong: (song: Song | null) => void;
  playSong: (song: Song, newQueue?: Song[]) => void;
  togglePlay: () => void;
  setPlaying: (playing: boolean) => void;
  setCurrentTime: (time: number) => void;
  setDuration: (duration: number) => void;
  nextSong: () => void;
  prevSong: () => void;
  seek: (time: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeatMode: () => void;
  toggleLike: (songId: string) => void;
  addToQueue: (song: Song) => void;
  removeFromQueue: (index: number) => void;
  reorderQueue: (from: number, to: number) => void;
  createPlaylist: (title: string, description?: string, coverUrl?: string) => string;
  editPlaylist: (id: string, title: string, description?: string) => void;
  deletePlaylist: (id: string) => void;
  addSongToPlaylist: (playlistId: string, song: Song) => void;
  removeSongFromPlaylist: (playlistId: string, songId: string) => void;
  setCurrentView: (view: ViewMode, playlistId?: string) => void;
  toggleFullScreen: () => void;
  setFullScreen: (open: boolean) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  openContextMenu: (x: number, y: number, song: Song) => void;
  closeContextMenu: () => void;
  setSearchQuery: (query: string) => void;
  setSearchFilter: (filter: 'all' | 'songs' | 'albums' | 'artists' | 'playlists') => void;
  showToast: (msg: string) => void;
  clearToast: () => void;
}

// LocalStorage helpers with fallback
const loadFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    if (typeof window === 'undefined') return defaultValue;
    const stored = localStorage.getItem(`soundwave_${key}`);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch {
    return defaultValue;
  }
};

const saveToStorage = <T>(key: string, value: T): void => {
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem(`soundwave_${key}`, JSON.stringify(value));
    }
  } catch {}
};

export const usePlayerStore = create<PlayerState>((set, get) => {
  const initialLiked = loadFromStorage<string[]>('liked_songs', ['sw-1', 'sw-2', 'sw-4', 'sw-7', 'sw-13', 'sw-32']);
  const initialPlaylists = loadFromStorage<Playlist[]>('playlists', INITIAL_PLAYLISTS);
  const initialRecent = loadFromStorage<Song[]>('recently_played', [SONGS_DATA[0], SONGS_DATA[1], SONGS_DATA[3]]);
  const initialVolume = loadFromStorage<number>('volume', 0.85);

  return {
    currentSong: SONGS_DATA[0],
    isPlaying: false,
    currentTime: 0,
    duration: SONGS_DATA[0].duration,
    volume: initialVolume,
    isMuted: false,
    isShuffle: false,
    repeatMode: 'off',
    queue: SONGS_DATA.slice(0, 15),
    queueIndex: 0,
    likedSongIds: initialLiked,
    recentlyPlayed: initialRecent,
    playlists: initialPlaylists,
    currentView: 'home',
    selectedPlaylistId: null,
    isFullScreen: false,
    isSidebarOpen: false,
    contextMenu: { isOpen: false, x: 0, y: 0, song: null },
    searchQuery: '',
    searchFilter: 'all',
    toastMessage: null,

    setCurrentSong: (song) => set({ currentSong: song }),

    playSong: (song, newQueue) => {
      const state = get();
      const queue = newQueue || state.queue;
      let qIndex = queue.findIndex((s) => s.id === song.id);
      let updatedQueue = queue;

      if (qIndex === -1) {
        updatedQueue = [song, ...queue];
        qIndex = 0;
      }

      // Add to recently played without duplicates
      const updatedRecent = [song, ...state.recentlyPlayed.filter((s) => s.id !== song.id)].slice(0, 20);
      saveToStorage('recently_played', updatedRecent);

      set({
        currentSong: song,
        queue: updatedQueue,
        queueIndex: qIndex,
        isPlaying: true,
        currentTime: 0,
        duration: song.duration,
        recentlyPlayed: updatedRecent
      });
    },

    togglePlay: () => {
      set((state) => ({ isPlaying: !state.isPlaying }));
    },

    setPlaying: (playing) => set({ isPlaying: playing }),

    setCurrentTime: (time) => set({ currentTime: time }),

    setDuration: (duration) => set({ duration }),

    nextSong: () => {
      const { queue, queueIndex, isShuffle, repeatMode, currentSong } = get();
      if (!queue.length) return;

      if (repeatMode === 'one' && currentSong) {
        set({ currentTime: 0, isPlaying: true });
        return;
      }

      let nextIndex = queueIndex + 1;
      if (isShuffle) {
        nextIndex = Math.floor(Math.random() * queue.length);
      } else if (nextIndex >= queue.length) {
        if (repeatMode === 'all') {
          nextIndex = 0;
        } else {
          set({ isPlaying: false });
          return;
        }
      }

      const nextTrack = queue[nextIndex];
      if (nextTrack) {
        get().playSong(nextTrack, queue);
      }
    },

    prevSong: () => {
      const { queue, queueIndex, currentTime } = get();
      if (currentTime > 4) {
        set({ currentTime: 0 });
        return;
      }
      let prevIndex = queueIndex - 1;
      if (prevIndex < 0) prevIndex = queue.length - 1;
      const prevTrack = queue[prevIndex];
      if (prevTrack) {
        get().playSong(prevTrack, queue);
      }
    },

    seek: (time) => {
      set({ currentTime: time });
    },

    setVolume: (vol) => {
      const clamped = Math.max(0, Math.min(1, vol));
      saveToStorage('volume', clamped);
      set({ volume: clamped, isMuted: clamped === 0 });
    },

    toggleMute: () => {
      set((state) => ({ isMuted: !state.isMuted }));
    },

    toggleShuffle: () => {
      set((state) => ({ isShuffle: !state.isShuffle }));
    },

    cycleRepeatMode: () => {
      const modes: RepeatMode[] = ['off', 'all', 'one'];
      const current = get().repeatMode;
      const nextIndex = (modes.indexOf(current) + 1) % modes.length;
      set({ repeatMode: modes[nextIndex] });
    },

    toggleLike: (songId) => {
      const state = get();
      const isLiked = state.likedSongIds.includes(songId);
      const updated = isLiked
        ? state.likedSongIds.filter((id) => id !== songId)
        : [...state.likedSongIds, songId];

      saveToStorage('liked_songs', updated);

      // Update liked songs playlist
      const likedSongsList = SONGS_DATA.filter((s) => updated.includes(s.id));
      const updatedPlaylists = state.playlists.map((pl) => {
        if (pl.id === 'pl-liked') {
          return { ...pl, songs: likedSongsList };
        }
        return pl;
      });
      saveToStorage('playlists', updatedPlaylists);

      set({ likedSongIds: updated, playlists: updatedPlaylists });
      get().showToast(isLiked ? 'Removed from Liked Songs' : 'Added to Liked Songs');
    },

    addToQueue: (song) => {
      set((state) => {
        const newQueue = [...state.queue, song];
        return { queue: newQueue };
      });
      get().showToast(`Added "${song.title}" to Queue`);
    },

    removeFromQueue: (index) => {
      set((state) => {
        const newQueue = [...state.queue];
        newQueue.splice(index, 1);
        return { queue: newQueue };
      });
    },

    reorderQueue: (from, to) => {
      set((state) => {
        const newQueue = [...state.queue];
        const [moved] = newQueue.splice(from, 1);
        newQueue.splice(to, 0, moved);
        return { queue: newQueue };
      });
    },

    createPlaylist: (title, description, coverUrl) => {
      const state = get();
      const newId = `pl-${Date.now()}`;
      const newPlaylist: Playlist = {
        id: newId,
        title: title.trim() || 'New Playlist',
        description: description || 'Created by you on SoundWave',
        coverUrl: coverUrl || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
        songs: [],
        isCustom: true
      };

      const updated = [...state.playlists, newPlaylist];
      saveToStorage('playlists', updated);
      set({ playlists: updated, currentView: 'playlist', selectedPlaylistId: newId });
      get().showToast(`Created playlist "${newPlaylist.title}"`);
      return newId;
    },

    editPlaylist: (id, title, description) => {
      const state = get();
      const updated = state.playlists.map((pl) =>
        pl.id === id ? { ...pl, title, description: description ?? pl.description } : pl
      );
      saveToStorage('playlists', updated);
      set({ playlists: updated });
      get().showToast('Playlist updated');
    },

    deletePlaylist: (id) => {
      const state = get();
      const updated = state.playlists.filter((pl) => pl.id !== id);
      saveToStorage('playlists', updated);
      set({
        playlists: updated,
        currentView: state.selectedPlaylistId === id ? 'home' : state.currentView,
        selectedPlaylistId: state.selectedPlaylistId === id ? null : state.selectedPlaylistId
      });
      get().showToast('Playlist deleted');
    },

    addSongToPlaylist: (playlistId, song) => {
      const state = get();
      const targetPl = state.playlists.find((pl) => pl.id === playlistId);
      if (!targetPl) return;

      if (targetPl.songs.some((s) => s.id === song.id)) {
        get().showToast(`Already in ${targetPl.title}`);
        return;
      }

      const updated = state.playlists.map((pl) => {
        if (pl.id === playlistId) {
          return { ...pl, songs: [...pl.songs, song] };
        }
        return pl;
      });

      saveToStorage('playlists', updated);
      set({ playlists: updated });
      get().showToast(`Added to "${targetPl.title}"`);
    },

    removeSongFromPlaylist: (playlistId, songId) => {
      const state = get();
      const targetPl = state.playlists.find((pl) => pl.id === playlistId);
      const updated = state.playlists.map((pl) => {
        if (pl.id === playlistId) {
          return { ...pl, songs: pl.songs.filter((s) => s.id !== songId) };
        }
        return pl;
      });

      saveToStorage('playlists', updated);
      set({ playlists: updated });
      get().showToast(targetPl ? `Removed from ${targetPl.title}` : 'Removed from playlist');
    },

    setCurrentView: (view, playlistId) => {
      set({ currentView: view, selectedPlaylistId: playlistId || null, isSidebarOpen: false });
    },

    toggleFullScreen: () => set((s) => ({ isFullScreen: !s.isFullScreen })),

    setFullScreen: (open) => set({ isFullScreen: open }),

    toggleSidebar: () => set((s) => ({ isSidebarOpen: !s.isSidebarOpen })),

    setSidebarOpen: (open) => set({ isSidebarOpen: open }),

    openContextMenu: (x, y, song) => {
      set({ contextMenu: { isOpen: true, x, y, song } });
    },

    closeContextMenu: () => {
      set({ contextMenu: { isOpen: false, x: 0, y: 0, song: null } });
    },

    setSearchQuery: (query) => set({ searchQuery: query }),

    setSearchFilter: (filter) => set({ searchFilter: filter }),

    showToast: (msg) => {
      set({ toastMessage: msg });
      setTimeout(() => {
        if (get().toastMessage === msg) {
          set({ toastMessage: null });
        }
      }, 3000);
    },

    clearToast: () => set({ toastMessage: null })
  };
});
