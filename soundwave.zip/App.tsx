import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft,
  ChevronRight,
  Play,
  Heart,
  Clock,
  Sparkles,
  Music,
  Compass,
  Radio,
  Sliders,
  Check
} from 'lucide-react';
import { usePlayerStore } from './store/usePlayerStore';
import { useAudio } from './hooks/useAudio';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { Sidebar } from './components/Sidebar';
import { HamburgerMenu } from './components/HamburgerMenu';
import { Player } from './components/Player';
import { FullScreenPlayer } from './components/FullScreenPlayer';
import { PlaylistCard } from './components/PlaylistCard';
import { SongRow } from './components/SongRow';
import { ContextMenu } from './components/ContextMenu';
import { LyricsPanel } from './components/LyricsPanel';
import { SearchBar } from './components/SearchBar';
import { SONGS_DATA } from './data/songs';

export const App: React.FC = () => {
  const {
    currentView,
    selectedPlaylistId,
    playlists,
    likedSongIds,
    recentlyPlayed,
    searchQuery,
    searchFilter,
    toastMessage,
    setCurrentView,
    playSong,
    clearToast
  } = usePlayerStore();

  const { seekTo } = useAudio();
  useKeyboardShortcuts(seekTo);

  const [isLyricsDrawerOpen, setIsLyricsDrawerOpen] = useState(false);

  // Real-time Indonesian greeting
  const getGreeting = (): string => {
    const hour = new Date().getHours();
    if (hour >= 4 && hour < 11) return 'Selamat Pagi';
    if (hour >= 11 && hour < 15) return 'Selamat Siang';
    if (hour >= 15 && hour < 19) return 'Selamat Sore';
    return 'Selamat Malam';
  };

  // Find active playlist if view is playlist
  const currentPlaylist = playlists.find((p) => p.id === selectedPlaylistId);
  const likedSongs = SONGS_DATA.filter((s) => likedSongIds.includes(s.id));

  // Search results logic
  const filteredSongs = SONGS_DATA.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    if (searchFilter === 'songs') return s.title.toLowerCase().includes(q);
    if (searchFilter === 'artists') return s.artist.toLowerCase().includes(q);
    if (searchFilter === 'albums') return s.album.toLowerCase().includes(q);
    return (
      s.title.toLowerCase().includes(q) ||
      s.artist.toLowerCase().includes(q) ||
      s.genre.toLowerCase().includes(q)
    );
  });

  const filteredPlaylists = playlists.filter((pl) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return pl.title.toLowerCase().includes(q) || pl.description.toLowerCase().includes(q);
  });

  return (
    <div className="h-screen w-screen bg-[#000000] text-white flex flex-col overflow-hidden font-sans select-none antialiased">
      {/* 3-Column Spotify Main Container */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar (260px) */}
        <Sidebar />

        {/* Middle Content Area */}
        <main className="flex-1 flex flex-col h-full bg-[#0A0A0A] overflow-hidden relative">
          {/* Top Bar Navigation */}
          <header className="h-16 px-4 md:px-8 flex items-center justify-between border-b border-white/10 bg-[#0A0A0A]/90 backdrop-blur-md sticky top-0 z-30 shrink-0">
            <div className="flex items-center gap-3">
              {/* Mobile Hamburger Menu Button */}
              <HamburgerMenu />

              {/* History Navigation Buttons */}
              <div className="hidden sm:flex items-center gap-2">
                <button
                  onClick={() => setCurrentView('home')}
                  className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
                  title="Back"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setCurrentView('search')}
                  className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
                  title="Forward"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Current View Breadcrumb / Status */}
              <div className="text-xs uppercase font-bold tracking-widest text-neutral-400 ml-2">
                {currentView === 'home' && 'SoundWave Premiere'}
                {currentView === 'search' && 'Search Library'}
                {currentView === 'library' && 'Your Library'}
                {currentView === 'liked' && 'Liked Songs'}
                {currentView === 'playlist' && (currentPlaylist?.title || 'Playlist')}
              </div>
            </div>

            {/* Top Right Quick Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentView('search')}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-neutral-300 hover:text-white hover:bg-white/10 transition-all"
              >
                <span>Jamendo API & Public Audio Connected</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </button>

              <button
                onClick={() => setIsLyricsDrawerOpen(!isLyricsDrawerOpen)}
                className="xl:hidden p-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-1.5"
                title="Toggle Now Playing & Lyrics"
              >
                <Music className="w-4 h-4" />
                <span className="hidden sm:inline">Now Playing</span>
              </button>
            </div>
          </header>

          {/* Scrollable Center Content */}
          <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 custom-scrollbar">
            {/* VIEW: HOME */}
            {currentView === 'home' && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-8 pb-8"
              >
                {/* Greeting Section */}
                <div>
                  <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
                    {getGreeting()}
                  </h1>

                  {/* 6 Quick-Access Cards Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 mt-5">
                    {playlists.slice(0, 6).map((pl) => (
                      <div
                        key={pl.id}
                        onClick={() => setCurrentView('playlist', pl.id)}
                        className="group flex items-center rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 transition-all cursor-pointer overflow-hidden shadow-sm"
                      >
                        <img
                          src={pl.coverUrl}
                          alt={pl.title}
                          className="w-16 h-16 object-cover border-r border-white/10 shrink-0"
                        />
                        <div className="flex-1 px-3.5 flex items-center justify-between truncate">
                          <span className="text-sm font-bold text-white truncate">
                            {pl.title}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (pl.songs.length > 0) playSong(pl.songs[0], pl.songs);
                            }}
                            className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-xl transition-all hover:scale-105 shrink-0"
                          >
                            <Play className="w-4 h-4 fill-black translate-x-0.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section: Recently Played */}
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold tracking-tight text-white">
                      Recently Played
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {recentlyPlayed.slice(0, 6).map((song) => (
                      <div
                        key={song.id}
                        onClick={() => playSong(song, recentlyPlayed)}
                        className="group p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 transition-all cursor-pointer flex flex-col"
                      >
                        <div className="relative aspect-square w-full rounded-lg overflow-hidden mb-2.5 shadow-md">
                          <img
                            src={song.coverUrl}
                            alt={song.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <button className="absolute bottom-2 right-2 w-8 h-8 rounded-full bg-white text-black flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="w-3.5 h-3.5 fill-black translate-x-0.5" />
                          </button>
                        </div>
                        <h4 className="text-xs font-bold text-white truncate">
                          {song.title}
                        </h4>
                        <p className="text-[11px] text-neutral-400 truncate mt-0.5">
                          {song.artist}
                        </p>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Section: Made For You */}
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold tracking-tight text-white">
                      Made For You
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {playlists.map((pl) => (
                      <PlaylistCard key={pl.id} playlist={pl} />
                    ))}
                  </div>
                </section>

                {/* Section: Popular Now (Songs Table) */}
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold tracking-tight text-white">
                      Popular Now
                    </h2>
                    <span className="text-xs text-neutral-500 font-mono">
                      Lossless Audio Quality
                    </span>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.02] p-2 space-y-1">
                    {SONGS_DATA.slice(0, 10).map((song, i) => (
                      <SongRow key={song.id} song={song} index={i} playlistContext={SONGS_DATA} />
                    ))}
                  </div>
                </section>
              </motion.div>
            )}

            {/* VIEW: SEARCH */}
            {currentView === 'search' && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6 pb-8"
              >
                <SearchBar />

                {searchQuery ? (
                  <div className="space-y-6">
                    <h3 className="text-lg font-bold text-white">
                      Results for &quot;{searchQuery}&quot;
                    </h3>

                    {/* Matching songs */}
                    {filteredSongs.length > 0 && (
                      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-2 space-y-1">
                        {filteredSongs.slice(0, 15).map((song, idx) => (
                          <SongRow
                            key={song.id}
                            song={song}
                            index={idx}
                            playlistContext={filteredSongs}
                          />
                        ))}
                      </div>
                    )}

                    {/* Matching playlists */}
                    {filteredPlaylists.length > 0 && (
                      <div>
                        <h4 className="text-sm font-bold text-neutral-300 mb-3 uppercase tracking-wider">
                          Playlists
                        </h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                          {filteredPlaylists.map((pl) => (
                            <PlaylistCard key={pl.id} playlist={pl} />
                          ))}
                        </div>
                      </div>
                    )}

                    {filteredSongs.length === 0 && filteredPlaylists.length === 0 && (
                      <div className="py-16 text-center text-neutral-500">
                        No songs or playlists matching &quot;{searchQuery}&quot;
                      </div>
                    )}
                  </div>
                ) : (
                  /* Browse Categories */
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-white">Browse All Genres</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {[
                        { title: 'Synthwave', color: 'bg-neutral-800' },
                        { title: 'Lo-Fi Chill', color: 'bg-neutral-850' },
                        { title: 'Ambient', color: 'bg-neutral-900' },
                        { title: 'Electronic', color: 'bg-neutral-800' },
                        { title: 'Jazz', color: 'bg-neutral-850' },
                        { title: 'Acoustic', color: 'bg-neutral-900' },
                        { title: 'Deep House', color: 'bg-neutral-800' },
                        { title: 'Techno', color: 'bg-neutral-850' },
                        { title: 'Cyberpunk', color: 'bg-neutral-900' },
                        { title: 'Post-Rock', color: 'bg-neutral-800' }
                      ].map((cat, i) => (
                        <div
                          key={i}
                          onClick={() => {
                            usePlayerStore.getState().setSearchQuery(cat.title);
                          }}
                          className="h-28 rounded-xl p-4 border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] hover:border-white/20 transition-all cursor-pointer flex flex-col justify-between"
                        >
                          <span className="font-bold text-base text-white">{cat.title}</span>
                          <span className="text-[11px] text-neutral-400">Curated Sounds</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* VIEW: LIBRARY */}
            {currentView === 'library' && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6 pb-8"
              >
                <div className="flex items-center justify-between">
                  <h1 className="text-2xl md:text-3xl font-bold text-white">Your Library</h1>
                  <span className="text-xs text-neutral-400 font-mono">
                    {playlists.length} Playlists • {likedSongIds.length} Liked
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                  {/* Liked Songs Special Card */}
                  <div
                    onClick={() => setCurrentView('liked')}
                    className="p-4 rounded-xl bg-gradient-to-br from-neutral-800 to-black border border-white/15 hover:border-white/30 transition-all cursor-pointer flex flex-col justify-between aspect-square"
                  >
                    <div className="w-10 h-10 rounded-lg bg-white/20 border border-white/30 flex items-center justify-center">
                      <Heart className="w-5 h-5 text-white fill-white" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-white">Liked Songs</h4>
                      <p className="text-xs text-neutral-400 mt-1">
                        {likedSongIds.length} favorite songs
                      </p>
                    </div>
                  </div>

                  {playlists.map((pl) => (
                    <PlaylistCard key={pl.id} playlist={pl} />
                  ))}
                </div>
              </motion.div>
            )}

            {/* VIEW: PLAYLIST DETAIL */}
            {currentView === 'playlist' && currentPlaylist && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6 pb-8"
              >
                {/* Playlist Banner Header */}
                <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6 pb-6 border-b border-white/10">
                  <img
                    src={currentPlaylist.coverUrl}
                    alt={currentPlaylist.title}
                    className="w-48 h-48 rounded-xl object-cover border border-white/20 shadow-2xl shrink-0"
                  />
                  <div className="space-y-2 text-center sm:text-left">
                    <span className="text-xs uppercase font-bold tracking-widest text-neutral-400">
                      Playlist
                    </span>
                    <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
                      {currentPlaylist.title}
                    </h1>
                    <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
                      {currentPlaylist.description}
                    </p>
                    <div className="text-xs text-neutral-500 font-mono pt-1">
                      {currentPlaylist.songs.length} songs • SoundWave Premiere
                    </div>
                  </div>
                </div>

                {/* Playlist Actions */}
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => {
                      if (currentPlaylist.songs.length > 0) {
                        playSong(currentPlaylist.songs[0], currentPlaylist.songs);
                      }
                    }}
                    className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-xl"
                  >
                    <Play className="w-5 h-5 fill-black translate-x-0.5" />
                  </button>
                </div>

                {/* Songs Table */}
                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-2 space-y-1">
                  {currentPlaylist.songs.length > 0 ? (
                    currentPlaylist.songs.map((song, i) => (
                      <SongRow
                        key={song.id + i}
                        song={song}
                        index={i}
                        playlistContext={currentPlaylist.songs}
                      />
                    ))
                  ) : (
                    <div className="py-16 text-center text-neutral-500 text-sm">
                      This playlist is empty. Add songs by right-clicking or tapping 3-dots on any song!
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* VIEW: LIKED SONGS */}
            {currentView === 'liked' && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6 pb-8"
              >
                {/* Liked Header */}
                <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6 pb-6 border-b border-white/10">
                  <div className="w-48 h-48 rounded-xl bg-gradient-to-tr from-neutral-900 to-neutral-700 border border-white/20 shadow-2xl flex items-center justify-center shrink-0">
                    <Heart className="w-20 h-20 text-white fill-white" />
                  </div>
                  <div className="space-y-2 text-center sm:text-left">
                    <span className="text-xs uppercase font-bold tracking-widest text-neutral-400">
                      Playlist
                    </span>
                    <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
                      Liked Songs
                    </h1>
                    <p className="text-xs sm:text-sm text-neutral-400">
                      All your favorite tracks saved in one place.
                    </p>
                    <div className="text-xs text-neutral-500 font-mono pt-1">
                      {likedSongs.length} songs
                    </div>
                  </div>
                </div>

                {/* Play Button */}
                {likedSongs.length > 0 && (
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => playSong(likedSongs[0], likedSongs)}
                      className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-xl"
                    >
                      <Play className="w-5 h-5 fill-black translate-x-0.5" />
                    </button>
                  </div>
                )}

                {/* Songs Table */}
                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-2 space-y-1">
                  {likedSongs.length > 0 ? (
                    likedSongs.map((song, i) => (
                      <SongRow key={song.id} song={song} index={i} playlistContext={likedSongs} />
                    ))
                  ) : (
                    <div className="py-16 text-center text-neutral-500 text-sm">
                      You haven&apos;t liked any songs yet. Tap the heart on any track to add it!
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </div>
        </main>

        {/* Right Sidebar (320px): Persistent on XL, Drawer on smaller screens */}
        <div className="hidden xl:block w-80 h-full shrink-0 z-20">
          <LyricsPanel seekTo={seekTo} />
        </div>

        {/* Slide-over Drawer for Lyrics on Tablet / Mobile */}
        <AnimatePresence>
          {isLyricsDrawerOpen && (
            <div className="fixed inset-0 z-50 xl:hidden flex justify-end">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsLyricsDrawerOpen(false)}
                className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              />
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
                className="relative z-50 w-80 max-w-full h-full shadow-2xl"
              >
                <LyricsPanel seekTo={seekTo} onClose={() => setIsLyricsDrawerOpen(false)} />
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Persistent Bottom Sticky Music Player Footer */}
      <Player
        seekTo={seekTo}
        onToggleLyricsDrawer={() => setIsLyricsDrawerOpen(!isLyricsDrawerOpen)}
      />

      {/* Full-Screen Music Player Modal */}
      <FullScreenPlayer seekTo={seekTo} />

      {/* Right-Click Context Menu */}
      <ContextMenu />

      {/* Global Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-[#1e1e1e] border border-white/20 text-white px-4 py-2.5 rounded-full text-xs font-medium shadow-2xl flex items-center gap-2"
          >
            <Check className="w-3.5 h-3.5 text-white" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
