import { useEffect } from 'react';
import { usePlayerStore } from '../store/usePlayerStore';

export const useKeyboardShortcuts = (seekTo?: (seconds: number) => void) => {
  const {
    togglePlay,
    currentTime,
    duration,
    seek,
    volume,
    setVolume,
    isFullScreen,
    setFullScreen,
    isSidebarOpen,
    setSidebarOpen,
    contextMenu,
    closeContextMenu,
    setCurrentView
  } = usePlayerStore();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input or textarea
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
        if (e.key === 'Escape') {
          target.blur();
        }
        return;
      }

      // Ctrl+K / Cmd+K -> Focus Search
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setCurrentView('search');
        setTimeout(() => {
          const searchInput = document.getElementById('soundwave-search-input');
          searchInput?.focus();
        }, 50);
        return;
      }

      switch (e.code) {
        case 'Space':
          e.preventDefault();
          togglePlay();
          break;

        case 'ArrowLeft':
          e.preventDefault();
          const prevTime = Math.max(0, currentTime - 5);
          seek(prevTime);
          if (seekTo) seekTo(prevTime);
          break;

        case 'ArrowRight':
          e.preventDefault();
          const nextTime = Math.min(duration, currentTime + 5);
          seek(nextTime);
          if (seekTo) seekTo(nextTime);
          break;

        case 'ArrowUp':
          e.preventDefault();
          setVolume(Math.min(1, volume + 0.05));
          break;

        case 'ArrowDown':
          e.preventDefault();
          setVolume(Math.max(0, volume - 0.05));
          break;

        case 'Escape':
          e.preventDefault();
          if (contextMenu.isOpen) {
            closeContextMenu();
          } else if (isFullScreen) {
            setFullScreen(false);
          } else if (isSidebarOpen) {
            setSidebarOpen(false);
          }
          break;

        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    togglePlay,
    currentTime,
    duration,
    seek,
    seekTo,
    volume,
    setVolume,
    isFullScreen,
    setFullScreen,
    isSidebarOpen,
    setSidebarOpen,
    contextMenu,
    closeContextMenu,
    setCurrentView
  ]);
};
