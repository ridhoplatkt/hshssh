import { useEffect, useRef } from 'react';
import { usePlayerStore } from '../store/usePlayerStore';

export const useAudio = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const {
    currentSong,
    isPlaying,
    volume,
    isMuted,
    currentTime,
    setCurrentTime,
    setDuration,
    setPlaying,
    nextSong,
    showToast
  } = usePlayerStore();

  // Initialize Audio
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const audio = new Audio();
    audio.preload = 'auto';
    audioRef.current = audio;

    const handleTimeUpdate = () => {
      if (audioRef.current) {
        setCurrentTime(audioRef.current.currentTime);
      }
    };

    const handleLoadedMetadata = () => {
      if (audioRef.current && audioRef.current.duration) {
        setDuration(audioRef.current.duration);
      }
    };

    const handleEnded = () => {
      nextSong();
    };

    const handleError = () => {
      // Audio error handling: try fallback sample
      if (audioRef.current && currentSong) {
        console.warn(`Audio stream failed for: ${currentSong.title}. Attempting fallback.`);
        const fallbackUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
        if (audioRef.current.src !== fallbackUrl) {
          audioRef.current.src = fallbackUrl;
          audioRef.current.play().catch(() => {});
          showToast(`Stream buffer refreshed for ${currentSong.title}`);
        } else {
          showToast(`Error playing ${currentSong.title}. Network or source unavailable.`);
          setPlaying(false);
        }
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
      audio.pause();
      audio.src = '';
    };
  }, []);

  // Update track source when currentSong changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentSong) return;

    if (audio.src !== currentSong.audioUrl) {
      audio.src = currentSong.audioUrl;
      audio.load();
      if (isPlaying) {
        audio.play().catch((err) => {
          console.warn('Autoplay prevented or network error:', err);
          setPlaying(false);
        });
      }
    }
  }, [currentSong]);

  // Handle play / pause toggle
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.play().catch((err) => {
        console.warn('Playback error:', err);
        setPlaying(false);
      });
    } else {
      audio.pause();
    }
  }, [isPlaying]);

  // Handle volume & mute
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = isMuted ? 0 : volume;
  }, [volume, isMuted]);

  // Seek helper
  const seekTo = (seconds: number) => {
    const audio = audioRef.current;
    if (audio) {
      audio.currentTime = seconds;
      setCurrentTime(seconds);
    }
  };

  return { audioRef, seekTo };
};
