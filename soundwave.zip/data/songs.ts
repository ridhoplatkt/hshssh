import { Song } from '../types';

export const SONGS_DATA: Song[] = [
  {
    id: 'sw-1',
    title: 'Midnight Echoes',
    artist: 'Aether Noir',
    album: 'Monochrome Dreams',
    duration: 372,
    genre: 'Synthwave',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    lyrics: [
      { time: 0, text: '♪ [Instrumental Synth Intro] ♪' },
      { time: 14, text: 'Walking down the empty boulevard' },
      { time: 26, text: 'Streetlights flickering through the dark' },
      { time: 42, text: 'Chasing shadows of what we used to be' },
      { time: 58, text: 'Midnight echoes calling back to me' },
      { time: 76, text: 'Neon fades into the silent rain' },
      { time: 94, text: 'Wash away the memory of pain' },
      { time: 115, text: '♪ [Electronic Bass Drop] ♪' },
      { time: 140, text: 'Can you hear the rhythm in the night?' },
      { time: 165, text: 'Guiding us towards the morning light' },
      { time: 190, text: 'Midnight echoes never fade away' },
      { time: 220, text: 'Leading us into another day' }
    ]
  },
  {
    id: 'sw-2',
    title: 'Urban Serenade',
    artist: 'Luna Rivera',
    album: 'City of Glass',
    duration: 423,
    genre: 'Lo-Fi Chill',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    lyrics: [
      { time: 0, text: '♪ [Soft Vinyl Crackle & Piano] ♪' },
      { time: 18, text: 'Coffee cools beside the windowsill' },
      { time: 34, text: 'Time moves fast but the room is still' },
      { time: 52, text: 'Soft whispers in the evening breeze' },
      { time: 70, text: 'Rustling through the quiet trees' },
      { time: 88, text: 'Urban serenade, sing me to sleep' },
      { time: 110, text: 'Promises we always swore to keep' },
      { time: 135, text: '♪ [Smooth Saxophone Interlude] ♪' },
      { time: 170, text: 'When the skyscrapers turn off their glow' },
      { time: 200, text: 'We find peace in the gentle undertow' }
    ]
  },
  {
    id: 'sw-3',
    title: 'Velvet Horizon',
    artist: 'Kaelen Vance',
    album: 'Infinite Void',
    duration: 345,
    genre: 'Ambient',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    lyrics: [
      { time: 0, text: '♪ [Deep Ambient Pad] ♪' },
      { time: 20, text: 'Drifting past the edge of sight' },
      { time: 45, text: 'Wrapped inside the velvet night' },
      { time: 70, text: 'Every star a story untold' },
      { time: 95, text: 'Stories worth more than gold' },
      { time: 125, text: 'Horizon breaks into silver dust' },
      { time: 160, text: 'In silence we place our trust' }
    ]
  },
  {
    id: 'sw-4',
    title: 'Electric Pulse',
    artist: 'Circuit Void',
    album: 'Cybernetic Flow',
    duration: 302,
    genre: 'Electronic',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    lyrics: [
      { time: 0, text: '♪ [Fast Arpeggiator Beat] ♪' },
      { time: 15, text: 'Voltage surging in the wire' },
      { time: 30, text: 'Fueling every wild desire' },
      { time: 50, text: 'Electric pulse inside the core' },
      { time: 72, text: 'Push the limits, ask for more' },
      { time: 100, text: '♪ [Techno Bass Drop] ♪' },
      { time: 130, text: 'We are circuits in the machine' },
      { time: 160, text: 'Living lives unseen' }
    ]
  },
  {
    id: 'sw-5',
    title: 'Gravity Well',
    artist: 'Nova Quartet',
    album: 'Orbital Mechanics',
    duration: 350,
    genre: 'Post-Rock',
    coverUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    lyrics: [
      { time: 0, text: '♪ [Melodic Guitar Strums] ♪' },
      { time: 25, text: 'Pull me close, don’t let me fall' },
      { time: 50, text: 'Echoes against the fortress wall' },
      { time: 80, text: 'Gravity pulls us right back down' },
      { time: 110, text: 'To the heart of this ancient town' }
    ]
  },
  {
    id: 'sw-6',
    title: 'Shadow Dancing',
    artist: 'Mira Solis',
    album: 'After Dark',
    duration: 280,
    genre: 'Dark Pop',
    coverUrl: 'https://images.unsplash.com/photo-1445985543469-433ecdd62977?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    lyrics: [
      { time: 0, text: '♪ [Subtle Hi-Hat & Snare] ♪' },
      { time: 12, text: 'Mirrors line the dimly lit hall' },
      { time: 28, text: 'Shadows dance against the wall' },
      { time: 48, text: 'Step by step, the tempo slows' },
      { time: 70, text: 'Where the midnight river flows' }
    ]
  },
  {
    id: 'sw-7',
    title: 'Astral Projection',
    artist: 'Cosmo Beats',
    album: 'Zero Gravity',
    duration: 315,
    genre: 'Chillhop',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    lyrics: [
      { time: 0, text: '♪ [Spacey Rhodes Chords] ♪' },
      { time: 22, text: 'Float above the atmosphere' },
      { time: 44, text: 'Everything is crystal clear' },
      { time: 70, text: 'Weightless now, we leave the ground' },
      { time: 98, text: 'Listening to cosmic sound' }
    ]
  },
  {
    id: 'sw-8',
    title: 'Reflections in Rain',
    artist: 'Elena Rostova',
    album: 'Nordic Winter',
    duration: 360,
    genre: 'Neoclassical',
    coverUrl: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    lyrics: [
      { time: 0, text: '♪ [Gentle Rain & Solo Piano] ♪' },
      { time: 30, text: 'Puddles reflect the cloudy sky' },
      { time: 65, text: 'Quietly watching the birds fly by' },
      { time: 105, text: 'A melancholic winter theme' },
      { time: 145, text: 'Awakening from a gentle dream' }
    ]
  },
  {
    id: 'sw-9',
    title: 'Neon Odyssey',
    artist: 'Vapor Waveform',
    album: 'Retro Future 1984',
    duration: 330,
    genre: 'Synthwave',
    coverUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
    lyrics: [
      { time: 0, text: '♪ [Gated Reverb Drums] ♪' },
      { time: 16, text: 'Cruising through the cyber street' },
      { time: 35, text: 'Matching our heartbeats to the beat' },
      { time: 60, text: 'Retro colors, violet haze' },
      { time: 85, text: 'Lost inside a digital maze' }
    ]
  },
  {
    id: 'sw-10',
    title: 'Canyon Whispers',
    artist: 'Sierra Ridge',
    album: 'Wilderness Echoes',
    duration: 295,
    genre: 'Acoustic',
    coverUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
    lyrics: [
      { time: 0, text: '♪ [Fingerpicked Acoustic Guitar] ♪' },
      { time: 14, text: 'Red rock valleys under open skies' },
      { time: 32, text: 'Truth beneath the eagles eyes' },
      { time: 55, text: 'Wind that whispers through the pines' },
      { time: 80, text: 'Nature reading between our lines' }
    ]
  },
  {
    id: 'sw-11',
    title: 'Deep Abyss',
    artist: 'Submariner',
    album: 'Oceanic Depths',
    duration: 388,
    genre: 'Deep House',
    coverUrl: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3',
    lyrics: [
      { time: 0, text: '♪ [Sub-bass Submerged Groove] ♪' },
      { time: 24, text: 'Diving deep below the blue' },
      { time: 48, text: 'Where thoughts are honest, clear, and true' },
      { time: 80, text: 'Pressure fades into the sound' },
      { time: 110, text: 'In the deep where peace is found' }
    ]
  },
  {
    id: 'sw-12',
    title: 'Solar Flare',
    artist: 'Hyperion',
    album: 'Stellar Radiation',
    duration: 320,
    genre: 'Electronic',
    coverUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',
    lyrics: [
      { time: 0, text: '♪ [High Energy Synth Arp] ♪' },
      { time: 18, text: 'Bursting through the corona ring' },
      { time: 40, text: 'Feel the heat the sun can bring' },
      { time: 70, text: 'Solar flare illuminates the dark' },
      { time: 95, text: 'Lighting up a blazing spark' }
    ]
  },
  {
    id: 'sw-13',
    title: 'Monochrome Cafe',
    artist: 'Trio Noir',
    album: 'Late Night Sessions',
    duration: 275,
    genre: 'Jazz',
    coverUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3',
    lyrics: [
      { time: 0, text: '♪ [Walking Bass & Brush Drums] ♪' },
      { time: 15, text: 'Corner table, cup of black' },
      { time: 35, text: 'Looking forward, no looking back' },
      { time: 60, text: 'Smoky room and muted brass' },
      { time: 90, text: 'Watching busy people pass' }
    ]
  },
  {
    id: 'sw-14',
    title: 'Quantum Leap',
    artist: 'Paradox Theory',
    album: 'Entanglement',
    duration: 340,
    genre: 'Techno',
    coverUrl: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3',
    lyrics: [
      { time: 0, text: '♪ [Pulsing Industrial Kick] ♪' },
      { time: 20, text: 'Two states existing in one space' },
      { time: 45, text: 'Speed of light in infinite race' },
      { time: 75, text: 'Quantum leap into the unknown' },
      { time: 105, text: 'Seeds of cosmos slowly sown' }
    ]
  },
  {
    id: 'sw-15',
    title: 'Morning Dew',
    artist: 'Aria Chen',
    album: 'Dawn Over East Lake',
    duration: 310,
    genre: 'Acoustic / Folk',
    coverUrl: 'https://images.unsplash.com/photo-1520523839898-507121c21051?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3',
    lyrics: [
      { time: 0, text: '♪ [Plucked Guzheng & Flute] ♪' },
      { time: 18, text: 'First light touches the water line' },
      { time: 38, text: 'A morning quiet and divine' },
      { time: 65, text: 'Pearls of dew on emerald leaves' },
      { time: 95, text: 'Gentle warmth the heart receives' }
    ]
  },
  {
    id: 'sw-16',
    title: 'Infinite Frequency',
    artist: 'Resonance Lab',
    album: 'Harmonic Series',
    duration: 365,
    genre: 'Electronic Ambient',
    coverUrl: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3',
    lyrics: [
      { time: 0, text: '♪ [Oscillating Sine Waves] ♪' },
      { time: 25, text: 'Tuning into the universal sound' },
      { time: 55, text: 'Where harmony and truth are found' },
      { time: 90, text: 'Infinite cycles round and round' },
      { time: 125, text: 'No beginning, no ending bound' }
    ]
  },
  {
    id: 'sw-17',
    title: 'Flute of Eternity',
    artist: 'Mythium Ensemble',
    album: 'Echoes of Ancient Past',
    duration: 245,
    genre: 'Instrumental',
    coverUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://archive.org/download/mythium/01_-_Flute_Song.mp3',
    lyrics: [
      { time: 0, text: '♪ [Solo Wooden Flute Melody] ♪' },
      { time: 20, text: 'Echoing across stone canyons' },
      { time: 45, text: 'Ancient travelers and companions' },
      { time: 70, text: 'A song that remembers ages gone' },
      { time: 95, text: 'Still playing until the dawn' }
    ]
  },
  {
    id: 'sw-18',
    title: 'The Hitchhiker',
    artist: 'Dust & Strings',
    album: 'Highway 61 Revisited',
    duration: 260,
    genre: 'Indie Rock',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://archive.org/download/mythium/02_-_The_Hitchhiker.mp3',
    lyrics: [
      { time: 0, text: '♪ [Driving Bass & Clean Guitar] ♪' },
      { time: 15, text: 'Thumb out on the dusty road' },
      { time: 30, text: 'Carrying a heavy load' },
      { time: 50, text: 'Headlights cut through evening haze' },
      { time: 75, text: 'Counting down the endless days' }
    ]
  },
  {
    id: 'sw-19',
    title: 'Northern Lights',
    artist: 'Aurora Chime',
    album: 'Polar Nights',
    duration: 330,
    genre: 'Chillout',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    lyrics: [
      { time: 0, text: '♪ [Shimmering Reverb Pads] ♪' },
      { time: 20, text: 'Green and violet dance across the sky' },
      { time: 42, text: 'Cold crisp air as temperatures drop' },
      { time: 65, text: 'Standing still at the mountain top' }
    ]
  },
  {
    id: 'sw-20',
    title: 'Synthetic Soul',
    artist: 'Binary Bloom',
    album: 'Future Nostalgia',
    duration: 290,
    genre: 'Synthwave',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    lyrics: [
      { time: 0, text: '♪ [Analog Synth Lead] ♪' },
      { time: 18, text: 'Can a machine learn how to feel?' },
      { time: 36, text: 'When the illusions start feeling real' },
      { time: 60, text: 'Synthetic soul yearning for touch' }
    ]
  },
  {
    id: 'sw-21',
    title: 'Velvet Midnight',
    artist: 'Miles & Shadow',
    album: 'Blue Note Echoes',
    duration: 310,
    genre: 'Jazz',
    coverUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    lyrics: [
      { time: 0, text: '♪ [Smooth Trumpet Solo] ♪' },
      { time: 20, text: 'Raindrops falling against the pane' },
      { time: 45, text: 'A lonely trumpet playing in the rain' },
      { time: 75, text: 'Sweet melodies linger in the night' }
    ]
  },
  {
    id: 'sw-22',
    title: 'Hyperdrive',
    artist: 'Vector Prime',
    album: 'Warp Speed',
    duration: 315,
    genre: 'Electronic',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    lyrics: [
      { time: 0, text: '♪ [Fast Tempo 138 BPM Techno] ♪' },
      { time: 16, text: 'Engaging hyperdrive right now' },
      { time: 32, text: 'Breaking through the sonic boundary' },
      { time: 55, text: 'Stars streak into lines of light' }
    ]
  },
  {
    id: 'sw-23',
    title: 'Rainy Boulevard',
    artist: 'Sora Tanaka',
    album: 'Tokyo After 2 AM',
    duration: 340,
    genre: 'Lo-Fi Chill',
    coverUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    lyrics: [
      { time: 0, text: '♪ [Rain Sound & Lo-Fi Rhodes] ♪' },
      { time: 25, text: 'Under an umbrella waiting for the train' },
      { time: 50, text: 'Reflections dancing on the wet asphalt' },
      { time: 80, text: 'Midnight lullaby for the restless mind' }
    ]
  },
  {
    id: 'sw-24',
    title: 'Ghost In The Machine',
    artist: 'Null Pointer',
    album: 'Segmentation Fault',
    duration: 295,
    genre: 'Cyberpunk',
    coverUrl: 'https://images.unsplash.com/photo-1445985543469-433ecdd62977?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    lyrics: [
      { time: 0, text: '♪ [Glitch Beats & Distorted Bass] ♪' },
      { time: 15, text: 'Data corrupted in memory address' },
      { time: 35, text: 'Finding signals in the digital distress' },
      { time: 60, text: 'I am the ghost within the code' }
    ]
  },
  {
    id: 'sw-25',
    title: 'Golden Hour Horizon',
    artist: 'Sunset Collective',
    album: 'Pacific Memories',
    duration: 325,
    genre: 'Acoustic Pop',
    coverUrl: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    lyrics: [
      { time: 0, text: '♪ [Warm 12-string Guitar] ♪' },
      { time: 18, text: 'Sun sinks low into the ocean line' },
      { time: 40, text: 'Sipping chilled sweet summer wine' },
      { time: 70, text: 'Warm golden hues embrace the sky' }
    ]
  },
  {
    id: 'sw-26',
    title: 'Iron & Dust',
    artist: 'Rust Belt Miners',
    album: 'Heavy Machinery',
    duration: 350,
    genre: 'Post-Rock',
    coverUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    lyrics: [
      { time: 0, text: '♪ [Distorted Bass & Heavy Cymbals] ♪' },
      { time: 22, text: 'Smokestacks reaching for gray clouds' },
      { time: 50, text: 'Voices fading in the crowds' },
      { time: 80, text: 'Iron will that never bends' }
    ]
  },
  {
    id: 'sw-27',
    title: 'Breathe In Deep',
    artist: 'Calm Waves',
    album: 'Meditation Series Vol. 4',
    duration: 360,
    genre: 'Ambient',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
    lyrics: [
      { time: 0, text: '♪ [Singing Bowls & Ocean Waves] ♪' },
      { time: 30, text: 'Inhale peace, exhale release' },
      { time: 70, text: 'Let your troubled worries cease' },
      { time: 110, text: 'Floating gently in this calm space' }
    ]
  },
  {
    id: 'sw-28',
    title: 'Neon Skyline',
    artist: 'Electra City',
    album: 'High Voltage',
    duration: 310,
    genre: 'Synthwave',
    coverUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
    lyrics: [
      { time: 0, text: '♪ [Punchy 80s Drum Machine] ♪' },
      { time: 14, text: 'Rooftops glowing in the dark' },
      { time: 32, text: 'Igniting an eternal spark' },
      { time: 58, text: 'Neon skyline stretching out for miles' }
    ]
  },
  {
    id: 'sw-29',
    title: 'Midnight Jazz Club',
    artist: 'The Quincy Trio',
    album: 'After 3 AM',
    duration: 285,
    genre: 'Jazz',
    coverUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3',
    lyrics: [
      { time: 0, text: '♪ [Upright Bass & Snare Brushes] ♪' },
      { time: 18, text: 'Last call at the basement bar' },
      { time: 42, text: 'Playing chords on a hollow-body guitar' },
      { time: 70, text: 'One last song before we say goodnight' }
    ]
  },
  {
    id: 'sw-30',
    title: 'Solar Eclipse',
    artist: 'Dark Horizon',
    album: 'Celestial Shadows',
    duration: 345,
    genre: 'Electronic',
    coverUrl: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',
    lyrics: [
      { time: 0, text: '♪ [Dramatic String Ensemble & Synth] ♪' },
      { time: 25, text: 'Day turns suddenly into night' },
      { time: 50, text: 'Corona glowing silver-white' },
      { time: 80, text: 'Totality captures every soul' }
    ]
  },
  {
    id: 'sw-31',
    title: 'Lo-Fi Raindrops',
    artist: 'Coffee & Books',
    album: 'Sunday Afternoon Study',
    duration: 270,
    genre: 'Lo-Fi Chill',
    coverUrl: 'https://images.unsplash.com/photo-1520523839898-507121c21051?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3',
    lyrics: [
      { time: 0, text: '♪ [Warm Cassette Tape Hiss] ♪' },
      { time: 15, text: 'Pages turning one by one' },
      { time: 35, text: 'Studying until the work is done' },
      { time: 60, text: 'Rain tapping softly on the roof' }
    ]
  },
  {
    id: 'sw-32',
    title: 'SoundWave Anthem',
    artist: 'SoundWave All-Stars',
    album: 'SoundWave Premiere Edition',
    duration: 380,
    genre: 'Electronic Masterpiece',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3',
    lyrics: [
      { time: 0, text: '♪ [Epic SoundWave Signature Intro] ♪' },
      { time: 20, text: 'Pure dark aesthetic, pristine sound' },
      { time: 42, text: 'The highest fidelity ever found' },
      { time: 68, text: 'Feel every frequency in your soul' },
      { time: 95, text: 'SoundWave music makes us whole' }
    ]
  }
];
