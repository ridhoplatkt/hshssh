import { Playlist } from '../types';
import { SONGS_DATA } from './songs';

export const INITIAL_PLAYLISTS: Playlist[] = [
  {
    id: 'pl-liked',
    title: 'Liked Songs',
    description: 'Your favorite tracks in one personal collection.',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    songs: [SONGS_DATA[0], SONGS_DATA[1], SONGS_DATA[3], SONGS_DATA[6], SONGS_DATA[12], SONGS_DATA[31]],
    isCustom: false
  },
  {
    id: 'pl-daily-1',
    title: 'Daily Mix 1',
    description: 'Aether Noir, Luna Rivera, Circuit Void and more curated for you.',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
    songs: [SONGS_DATA[0], SONGS_DATA[1], SONGS_DATA[2], SONGS_DATA[3], SONGS_DATA[8], SONGS_DATA[11]],
    isCustom: false
  },
  {
    id: 'pl-chill-vibes',
    title: 'Chill Vibes',
    description: 'Relaxing lo-fi beats, soothing acoustics, and ambient horizons.',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    songs: [SONGS_DATA[1], SONGS_DATA[2], SONGS_DATA[6], SONGS_DATA[7], SONGS_DATA[9], SONGS_DATA[14], SONGS_DATA[30]],
    isCustom: false
  },
  {
    id: 'pl-workout',
    title: 'Workout & Energy',
    description: 'High tempo electronics, aggressive synth, and bass heavy motivation.',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80',
    songs: [SONGS_DATA[3], SONGS_DATA[11], SONGS_DATA[13], SONGS_DATA[21], SONGS_DATA[23], SONGS_DATA[27]],
    isCustom: false
  },
  {
    id: 'pl-focus',
    title: 'Deep Focus & Flow',
    description: 'Uninterrupted instrumental soundscapes to fuel maximum concentration.',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
    songs: [SONGS_DATA[2], SONGS_DATA[7], SONGS_DATA[10], SONGS_DATA[15], SONGS_DATA[16], SONGS_DATA[26]],
    isCustom: false
  }
];
